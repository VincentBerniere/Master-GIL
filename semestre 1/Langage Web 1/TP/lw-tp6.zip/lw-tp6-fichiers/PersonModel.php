<?php

class PersonModel {
	private static $surnames = ['Dupont', 'Dubois', 'Durand', 'Petit', 'Leroy', 'Moreau', 'Lefebvre', 'Garcia', 'Roux', 'Fournier', 'Morel', 'Girard', 'Mercier', 'Lambert', 'Bonnet', 'Martinez', 'Legrand', 'Garnier', 'Faure', 'Rousseau', 'Blanc', 'Guerin', 'Muller', 'Henry', 'roussel', 'Perrin', 'Morin', 'Dumont'];

	private static $ladies = ['Emma', 'Lea', 'Jade', 'Manon', 'Chloe', 'Ines', 'Camille', 'Clara', 'Sarah', 'Lola', 'Zoe', 'Louise', 'Eva'];
	private static $gents = ['Lucas', 'Enzo', 'Nathan', 'Mathis', 'Louis', 'Hugo', 'Maxime', 'Jules', 'Thomas', 'Tom', 'Raphael', 'Gabriel', 'Matheo', 'Theo'];
}

?>